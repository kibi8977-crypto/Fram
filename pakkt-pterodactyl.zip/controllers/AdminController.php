<?php

namespace Pterodactyl\Http\Controllers\Admin\Extensions\Pakkt;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Http;
use Illuminate\View\View;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\Node;

class AdminController extends Controller
{
    private const API_URL = 'https://api.pakkt.io';

    private function config(string $key, string $default = ''): string
    {
        return DB::table('pakkt_config')->where('key', $key)->value('value') ?? $default;
    }

    private function setConfig(array $pairs): void
    {
        $rows = array_map(fn($k, $v) => ['key' => $k, 'value' => $v], array_keys($pairs), $pairs);
        DB::table('pakkt_config')->upsert($rows, ['key'], ['value']);
    }

    private function pakktGet(string $path): array
    {
        $api_key = $this->config('api_key');
        try {
            $response = Http::timeout(8)
                ->withHeaders(['X-API-Key' => $api_key])
                ->get(self::API_URL . '/api' . $path);
            return ['ok' => $response->successful(), 'data' => $response->json(), 'status' => $response->status()];
        } catch (\Exception $e) {
            return ['ok' => false, 'data' => null, 'status' => 0, 'error' => $e->getMessage()];
        }
    }

    public function index(): View
    {
        $api_key     = $this->config('api_key');
        $trial_token = $this->config('trial_token');
        $nodes       = Node::all(['id', 'name', 'fqdn']);
        $node_agents = DB::table('pakkt_node_agents')->get()->keyBy('node_id');

        $pakkt_agents      = [];
        $connection_status = null;
        $subscription      = null;

        if ($api_key) {
            $agents_res = $this->pakktGet('/v1/agents');
            if ($agents_res['ok']) {
                $pakkt_agents      = $agents_res['data'] ?? [];
                $connection_status = 'ok';
            } else {
                $connection_status = 'error';
            }
            $sub_res = $this->pakktGet('/v1/billing');
            if ($sub_res['ok']) $subscription = $sub_res['data'];
        }

        return view('extensions.pakkt.admin', compact(
            'api_key', 'trial_token', 'nodes', 'node_agents',
            'pakkt_agents', 'connection_status', 'subscription'
        ));
    }

    public function saveSettings(Request $request): RedirectResponse
    {
        $request->validate(['api_key' => 'required|string|min:10|max:128']);
        $this->setConfig(['api_key' => trim($request->input('api_key'))]);
        $res = $this->pakktGet('/v1/agents');
        $status = $res['ok'] ? 'Connexion PAKKT vérifiée.' : 'Clé sauvegardée mais la connexion a échoué (code ' . $res['status'] . ').';
        return redirect()->route('admin.extensions.pakkt.index')->with('success', $status);
    }

    public function saveNodeMappings(Request $request): RedirectResponse
    {
        $mappings = array_filter(
            $request->input('mappings', []),
            fn($agent_id) => trim((string) $agent_id) !== ''
        );
        if (empty($mappings)) {
            return redirect()->route('admin.extensions.pakkt.index')->with('error', 'Aucun mapping fourni.');
        }
        DB::table('pakkt_node_agents')->truncate();
        foreach ($mappings as $node_id => $agent_id) {
            $agent_id = trim($agent_id);
            if ($agent_id !== '') {
                DB::table('pakkt_node_agents')->insert([
                    'node_id'    => (int) $node_id,
                    'agent_id'   => $agent_id,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
        }
        return redirect()->route('admin.extensions.pakkt.index')->with('success', 'Mapping nodes → agents sauvegardé.');
    }
}
