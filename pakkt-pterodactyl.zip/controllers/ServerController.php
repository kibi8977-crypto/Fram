<?php

namespace Pterodactyl\Http\Controllers\Server\Extensions\Pakkt;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\ValidationException;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\JsonResponse;
use Illuminate\View\View;
use Pterodactyl\Http\Controllers\Controller;
use Pterodactyl\Models\Server;

class ServerController extends Controller
{
    private function config(string $key, string $default = ''): string
    {
        return DB::table('pakkt_config')->where('key', $key)->value('value') ?? $default;
    }

    /**
     * Returns all ports allocated to the given server (primary + additional allocations).
     *
     * @return int[]
     */
    private function serverPorts(Server $server): array
    {
        return DB::table('allocations')
            ->where('server_id', $server->id)
            ->pluck('port')
            ->map(fn($p) => (int) $p)
            ->toArray();
    }

    /**
     * Returns the PAKKT agent_id mapped to the node hosting this server, or null.
     */
    private function agentId(Server $server): ?string
    {
        return DB::table('pakkt_node_agents')
            ->where('node_id', $server->node_id)
            ->value('agent_id');
    }

    /**
     * Validates that a given port range is fully within at least one allocated port.
     *
     * For XDP rules, we allow a single port (start == end) or a range — but every
     * individual port in the range must exist as an allocation.
     * In practice game servers get specific ports, so we check both bounds.
     */
    private function portsAllowed(int $port_start, int $port_end, array $allocated): bool
    {
        return in_array($port_start, $allocated, true) && in_array($port_end, $allocated, true);
    }

    private const API_URL = 'https://api.pakkt.io';

    private function pakktRequest(string $method, string $path, array $body = []): array
    {
        $api_key = $this->config('api_key');

        try {
            $req = Http::timeout(8)->withHeaders(['X-API-Key' => $api_key]);
            $response = match (strtoupper($method)) {
                'GET'    => $req->get(self::API_URL . '/api' . $path),
                'POST'   => $req->post(self::API_URL . '/api' . $path, $body),
                'DELETE' => $req->delete(self::API_URL . '/api' . $path),
                default  => throw new \InvalidArgumentException("Unsupported method: $method"),
            };

            return ['ok' => $response->successful(), 'data' => $response->json(), 'status' => $response->status()];
        } catch (\Exception $e) {
            return ['ok' => false, 'data' => null, 'status' => 0, 'error' => $e->getMessage()];
        }
    }

    /**
     * Returns a JSON or redirect response depending on whether the request expects JSON
     * (e.g., widget AJAX calls send Accept: application/json).
     */
    private function respond(Request $request, string $msg, bool $ok = true, int $fail_status = 422): RedirectResponse|JsonResponse
    {
        if ($ok) {
            return $request->wantsJson()
                ? response()->json(['success' => true, 'message' => $msg])
                : back()->with('success', $msg);
        }
        return $request->wantsJson()
            ? response()->json(['error' => $msg], $fail_status)
            : back()->with('error', $msg);
    }

    /**
     * Normalise limit_unit from short form ('second', 'minute', 'hour') to the
     * form expected by the PAKKT API ('packets/second', etc.).
     * Already-normalized long forms are returned unchanged.
     */
    private function normalizeLimitUnit(?string $unit): ?string
    {
        return match ($unit) {
            'second' => 'packets/second',
            'minute' => 'packets/minute',
            'hour'   => 'packets/hour',
            default  => $unit,
        };
    }

    /**
     * Read input from the request, preferring the raw JSON body (json_decode of getContent)
     * over Laravel's standard input parsing, which can miss JSON bodies in Pterodactyl's
     * web middleware stack.
     */
    private function inputFromRequest(Request $request): array
    {
        $input = json_decode($request->getContent(), true) ?? [];
        return !empty($input) ? $input : $request->all();
    }

    public function index(Request $request, string $server_uuid): View
    {
        $server     = Server::where('uuidShort', $server_uuid)->firstOrFail();
        $agent_id   = $this->agentId($server);
        $ports      = $this->serverPorts($server);
        $api_key    = $this->config('api_key');
        $configured = (bool) $api_key;

        $xdp_programs = [];
        $nft_rules    = [];
        $agent_online = false;
        $templates    = [];

        if ($agent_id && $configured) {

            // All four requests are independent — run in parallel.
            // $agent_id comes from the local Pterodactyl DB, not from the PAKKT API.
            try {
                [$agent_res, $prog_res, $nft_res, $tpl_res] = Http::pool(fn ($pool) => [
                    $pool->timeout(8)->withHeaders(['X-API-Key' => $api_key])
                        ->get(self::API_URL . '/api/v1/agents/' . $agent_id),
                    $pool->timeout(8)->withHeaders(['X-API-Key' => $api_key])
                        ->get(self::API_URL . '/api/v1/agents/' . $agent_id . '/programs'),
                    $pool->timeout(8)->withHeaders(['X-API-Key' => $api_key])
                        ->get(self::API_URL . '/api/v1/agents/' . $agent_id . '/firewall'),
                    $pool->timeout(8)->withHeaders(['X-API-Key' => $api_key])
                        ->get(self::API_URL . '/api/v1/marketplace/templates?category=Gaming'),
                ]);

                if ($agent_res->successful()) {
                    $agent_online = ($agent_res->json('status') ?? '') === 'online';
                }

                if ($prog_res->successful() && is_array($prog_res->json())) {
                    $xdp_programs = array_values(array_filter(
                        $prog_res->json(),
                        fn($p) => (int)($p['port_range_start'] ?? 0) > 0
                            && in_array((int)($p['port_range_start'] ?? 0), $ports, true)
                            && in_array((int)($p['port_range_end'] ?? 0), $ports, true)
                    ));
                }

                if ($nft_res->successful() && is_array($nft_res->json())) {
                    $nft_rules = array_values(array_filter(
                        $nft_res->json(),
                        fn($r) => (int)($r['port_start'] ?? 0) > 0
                            && in_array((int)($r['port_start'] ?? 0), $ports, true)
                            && in_array((int)($r['port_end'] ?? 0), $ports, true)
                    ));
                }

                if ($tpl_res->successful() && is_array($tpl_res->json())) {
                    // Exclude all-port templates — Pterodactyl users can only manage their allocated ports
                    $templates = array_values(array_filter($tpl_res->json(), function ($t) {
                        if (($t['type'] ?? '') === 'nftables') {
                            return ($t['nft']['port_start'] ?? 0) > 0;
                        }
                        return ($t['port_range_start'] ?? 0) > 0;
                    }));
                }
            } catch (\Exception) {
                // Network failure — views handle empty data gracefully.
            }
        }

        return view('extensions.pakkt.server', compact(
            'server', 'agent_id', 'ports', 'configured',
            'xdp_programs', 'nft_rules', 'agent_online', 'templates'
        ));
    }

    public function createXdpRule(Request $request, string $server_uuid): RedirectResponse|JsonResponse
    {
        $server   = Server::where('uuidShort', $server_uuid)->firstOrFail();
        $agent_id = $this->agentId($server);
        $ports    = $this->serverPorts($server);

        if (!$agent_id) {
            return $this->respond($request, 'Aucun agent PAKKT associé à ce node.', false);
        }

        try {
            $validated = Validator::make($this->inputFromRequest($request), [
                'name'          => 'required|string|max:128',
                'port_start'    => 'required|integer|min:1|max:65535',
                'port_end'      => 'required|integer|min:1|max:65535|gte:port_start',
                'protocol'      => 'required|in:0,6,17',
                'rule_type'     => 'required|in:0,1,2',
                'max_pps'       => 'required|integer|min:1|max:10000000',
                'max_port_pps'  => 'nullable|integer|min:0',
                'min_pkt_size'  => 'nullable|integer|min:0',
                'max_pkt_size'  => 'nullable|integer|min:0',
            ])->validate();
        } catch (ValidationException $e) {
            $msg = collect($e->errors())->flatten()->implode(', ');
            return $this->respond($request, $msg, false, 422);
        }

        if (!$this->portsAllowed((int)$validated['port_start'], (int)$validated['port_end'], $ports)) {
            return $this->respond($request, 'Les ports doivent faire partie de vos allocations serveur.', false);
        }

        $res = $this->pakktRequest('POST', '/v1/agents/' . $agent_id . '/engine-rules', [
            'name'             => $validated['name'],
            'port_range_start' => (int)$validated['port_start'],
            'port_range_end'   => (int)$validated['port_end'],
            'protocol'         => (int)$validated['protocol'],
            'rule_type'        => (int)$validated['rule_type'],
            'max_pps'          => (int)$validated['max_pps'],
            'max_port_pps'     => (int)($validated['max_port_pps'] ?? 0),
            'min_pkt_size'     => (int)($validated['min_pkt_size'] ?? 0),
            'max_pkt_size'     => (int)($validated['max_pkt_size'] ?? 0),
        ]);

        if ($res['ok']) {
            return $this->respond($request, 'Règle XDP créée, déploiement en cours.');
        }

        $err = $res['data']['error'] ?? ('Erreur API (' . $res['status'] . ')');
        return $this->respond($request, $err, false);
    }

    public function deleteXdpRule(Request $request, string $server_uuid, string $program_id): RedirectResponse|JsonResponse
    {
        $server   = Server::where('uuidShort', $server_uuid)->firstOrFail();
        $agent_id = $this->agentId($server);
        $ports    = $this->serverPorts($server);

        if (!$agent_id) {
            return $this->respond($request, 'Aucun agent PAKKT associé à ce node.', false);
        }

        // Verify the program belongs to this server's ports before deleting
        $prog_res = $this->pakktRequest('GET', '/v1/agents/' . $agent_id . '/programs');
        if (!$prog_res['ok']) {
            return $this->respond($request, 'Impossible de récupérer les programmes.', false, 502);
        }

        $program = collect(is_array($prog_res['data']) ? $prog_res['data'] : [])
            ->firstWhere('id', $program_id);

        if (!$program || !$this->portsAllowed(
            (int)($program['port_range_start'] ?? 0),
            (int)($program['port_range_end'] ?? 0),
            $ports
        )) {
            return $this->respond($request, 'Programme introuvable ou hors de vos allocations.', false);
        }

        $res = $this->pakktRequest('DELETE', '/v1/agents/' . $agent_id . '/programs/' . $program_id);

        return $res['ok']
            ? $this->respond($request, 'Règle XDP supprimée.')
            : $this->respond($request, 'Erreur lors de la suppression.', false, 502);
    }

    public function createNftRule(Request $request, string $server_uuid): RedirectResponse|JsonResponse
    {
        $server   = Server::where('uuidShort', $server_uuid)->firstOrFail();
        $agent_id = $this->agentId($server);
        $ports    = $this->serverPorts($server);

        if (!$agent_id) {
            return $this->respond($request, 'Aucun agent PAKKT associé à ce node.', false);
        }

        try {
            $validated = Validator::make($this->inputFromRequest($request), [
                'name'       => 'required|string|max:64',
                'port_start' => 'nullable|integer|min:0|max:65535',
                'port_end'   => 'nullable|integer|min:0|max:65535',
                'protocol'   => 'required|in:tcp,udp,icmp,any',
                'action'     => 'required|in:drop,accept,reject,limit',
                'limit_rate' => 'nullable|integer|min:1',
                'limit_unit' => 'nullable|in:packets/second,packets/minute,packets/hour,second,minute,hour',
                'conntrack'  => 'nullable|string|max:32',
                'priority'   => 'nullable|integer',
            ])->validate();
        } catch (ValidationException $e) {
            $msg = collect($e->errors())->flatten()->implode(', ');
            return $this->respond($request, $msg, false, 422);
        }

        $port_start = (int)($validated['port_start'] ?? 0);
        $port_end   = (int)($validated['port_end']   ?? 0);

        // For protocol=icmp/any, ports are 0 — skip port ownership check
        if ($port_start > 0 && !$this->portsAllowed($port_start, $port_end, $ports)) {
            return $this->respond($request, 'Les ports doivent faire partie de vos allocations serveur.', false);
        }

        $res = $this->pakktRequest('POST', '/v1/agents/' . $agent_id . '/firewall', [
            'name'       => $validated['name'],
            'chain'      => 'input',
            'protocol'   => $validated['protocol'],
            'port_start' => $port_start ?: null,
            'port_end'   => $port_end   ?: null,
            'action'     => $validated['action'],
            'limit_rate' => isset($validated['limit_rate']) ? (int)$validated['limit_rate'] : null,
            'limit_unit' => $validated['limit_unit'] ?? null,
            'conntrack'  => $validated['conntrack'] ?? null,
            'priority'   => (int)($validated['priority'] ?? 0),
        ]);

        if ($res['ok']) {
            return $this->respond($request, 'Règle NFT créée, déploiement en cours.');
        }

        $err = $res['data']['error'] ?? ('Erreur API (' . $res['status'] . ')');
        return $this->respond($request, $err, false);
    }

    public function deleteNftRule(Request $request, string $server_uuid, string $rule_id): RedirectResponse|JsonResponse
    {
        $server   = Server::where('uuidShort', $server_uuid)->firstOrFail();
        $agent_id = $this->agentId($server);
        $ports    = $this->serverPorts($server);

        if (!$agent_id) {
            return $this->respond($request, 'Aucun agent PAKKT associé à ce node.', false);
        }

        // Verify rule belongs to this server's ports
        $nft_res = $this->pakktRequest('GET', '/v1/agents/' . $agent_id . '/firewall');
        if (!$nft_res['ok']) {
            return $this->respond($request, 'Impossible de récupérer les règles.', false, 502);
        }

        $rule = collect(is_array($nft_res['data']) ? $nft_res['data'] : [])->firstWhere('id', $rule_id);

        $rule_port_start = (int)($rule['port_start'] ?? 0);
        $rule_port_end   = (int)($rule['port_end']   ?? 0);
        // Block: rule not found, port=0 (all-ports rule — not owned by this server), or ports outside allocations
        if (!$rule || $rule_port_start === 0 || !$this->portsAllowed($rule_port_start, $rule_port_end, $ports)) {
            return $this->respond($request, 'Règle introuvable ou hors de vos allocations.', false);
        }

        $res = $this->pakktRequest('DELETE', '/v1/agents/' . $agent_id . '/firewall/' . $rule_id);

        return $res['ok']
            ? $this->respond($request, 'Règle NFT supprimée.')
            : $this->respond($request, 'Erreur lors de la suppression.', false, 502);
    }

    public function stats(Request $request, string $server_uuid): JsonResponse
    {
        $server   = Server::where('uuidShort', $server_uuid)->firstOrFail();
        $agent_id = $this->agentId($server);

        if (!$agent_id) {
            return response()->json(['error' => 'No agent configured'], 404);
        }

        $window = in_array($request->query('window'), ['10m', '1h', '24h'], true)
            ? $request->query('window')
            : '1h';

        // Build ports filter from server allocations (XDP + NFT scoped to this server)
        $ports      = $this->serverPorts($server);
        $ports_qs   = count($ports) ? '&ports=' . implode(',', $ports) : '';
        $api_key    = $this->config('api_key');

        // Fetch summary + history in parallel
        [$summary_res, $history_res] = Http::pool(fn ($pool) => [
            $pool->timeout(8)->withHeaders(['X-API-Key' => $api_key])
                ->get(self::API_URL . '/api/v1/metrics/' . $agent_id . '/summary?window=' . $window . $ports_qs),
            $pool->timeout(8)->withHeaders(['X-API-Key' => $api_key])
                ->get(self::API_URL . '/api/v1/metrics/' . $agent_id . '?interval=5m' . $ports_qs),
        ]);

        if (!$summary_res->successful()) {
            return response()->json(['error' => 'Failed to fetch metrics'], 502);
        }

        return response()->json([
            'summary' => $summary_res->json(),
            'history' => $history_res->successful() ? $history_res->json() : [],
        ]);
    }
}
