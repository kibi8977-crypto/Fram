<?php

use Illuminate\Support\Facades\Route;
use Pterodactyl\Http\Controllers\Server\Extensions\Pakkt\ServerController;

Route::prefix('server')->middleware(['web', 'auth'])->group(function () {
    Route::get('/{server_uuid}/pakkt', [ServerController::class, 'index'])->name('server.extensions.pakkt.index');
    Route::post('/{server_uuid}/pakkt/xdp', [ServerController::class, 'createXdpRule'])->name('server.extensions.pakkt.xdp.create');
    Route::delete('/{server_uuid}/pakkt/xdp/{program_id}', [ServerController::class, 'deleteXdpRule'])->name('server.extensions.pakkt.xdp.delete');
    Route::post('/{server_uuid}/pakkt/nft', [ServerController::class, 'createNftRule'])->name('server.extensions.pakkt.nft.create');
    Route::delete('/{server_uuid}/pakkt/nft/{rule_id}', [ServerController::class, 'deleteNftRule'])->name('server.extensions.pakkt.nft.delete');
    Route::get('/{server_uuid}/pakkt/stats', [ServerController::class, 'stats'])->name('server.extensions.pakkt.stats');
});
