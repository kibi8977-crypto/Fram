<?php

use Illuminate\Support\Facades\Route;
use Pterodactyl\Http\Controllers\Admin\Extensions\Pakkt\AdminController;

Route::prefix('extensions/pakkt')->group(function () {
    Route::get('/', [AdminController::class, 'index'])->name('admin.extensions.pakkt.index');
    Route::post('/settings', [AdminController::class, 'saveSettings'])->name('admin.extensions.pakkt.settings');
    Route::post('/nodes', [AdminController::class, 'saveNodeMappings'])->name('admin.extensions.pakkt.nodes');
});
