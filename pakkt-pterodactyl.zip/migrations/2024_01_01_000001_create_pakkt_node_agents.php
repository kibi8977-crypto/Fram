<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('pakkt_node_agents', function (Blueprint $table) {
            $table->unsignedInteger('node_id')->primary();
            $table->string('agent_id', 64);
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('pakkt_node_agents');
    }
};
